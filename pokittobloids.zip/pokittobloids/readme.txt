Hi there!

Thanks for checking out our game! We appreciate it.

When extracting this .zip file, please copy the bloids folder to the root of your SD card. The structure should look like this:

bloids/gameSong.wav
bloids/menuSong.wav
Bloids.bin

Instructions:
(Menu)
A: Start game
B: Game info
Left: Music on
Right: Music off

(Game)
D-pad: Move face pieces from the centre block into one of the four available blocks to complete a face. A completed face with matching pieces gives you a coin and 100 points. A completed face with non-matching pieces gives you just 50 points.
B: Use coin to buy another center piece to place.
Placing a piece into a block where another piece occupies the same position, causes you to lose a life.

This game is based on Quartet by Photon Storm. My take adds the twist of using a coin to clear out a random box of face pieces when you're stuck with a center piece you cannot place.

Check out more of our games at http://blackjet.co.uk
